Instructions included in menu of game

Regards,

Sanguine Labs
