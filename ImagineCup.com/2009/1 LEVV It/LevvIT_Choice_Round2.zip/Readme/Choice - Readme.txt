  _____ _           _          
 / ____| |         (_)         
| |    | |__   ___  _  ___ ___ 
| |    | '_ \ / _ \| |/ __/ _ \
| |____| | | | (_) | | (_|  __/
 \_____|_| |_|\___/|_|\___\___|

******************************
* The World is on your hands *
******************************

===== TABLE OF CONTENTS ======
 
1. Game Controls

2. How to Play
  2.1 Starting a Match
  2.2 Goal Pieces
  2.3 Natural Disasters

3. Advanced Choices [Optional]
  3.1 Making your strategy
  3.2 Partnerships


===== 1. GAME CONTROLS =======

Confirm / Select ................ RT or LT
Move Cursor ..................... Left Analog Stick, Right Analog Stick
Select Goal Piece ............... A, B, X, Y 


===== 2. HOW TO PLAY =========
--------------------
2.1 Starting a match
--------------------
To start a match, the player using the first controller must select Quickplay from the Main Menu. To 
make a selection, move the cursor to the desired option and push RT or LT. 

In the next screen, all players will be asked to choose a color. By doing so, a random objective will be 
automatically assigned to each of the players. An objective consists of one Territory and the Millennium
Development Goal that that territory needs to achieve. The first player to achieve that Millennium Goal
on his objective territory wins the match.  

Once the players are done selecting their colors, the first player must select the �Continue� button. By 
doing that, the remaining colors will be taken over by AI-controlled players. This way, every Choice 
match always has four players. 

--------------------
2.2 Goal Pieces
--------------------
As the game begins you will notice, on the top of the screen, various people working together to make 
the Millennium Development Goals come true. They will be carrying pieces called Goal Pieces. These are 
the artifacts that you will be using to make your territory achieve a Goal and thus win the match. When 
the people manage to fill the center slots with four goal pieces, they will fall down assuming random 
positions on the sliced disc. Once that happens, they will all become available to all players at the same 
time, which means that anyone who presses the corresponding button first will get that Goal Piece to 
use in his/her strategy. 

Once you�ve gotten a Goal Piece, you can use it by bringing it to the destination territory, and press the 
confirm button (RT or LT) to drop it. 

--------------------
2.3 Spendables 
--------------------
From time to time natural disasters may happen on random territories. When that happens, the game 
dynamics change momentarily: while the disaster is happening, a special type of Goal Piece will appear. 
This forces the players to put their strategies on hold for a moment and focus on helping the damaged 
territory. The difference is that only 3 Pieces will be available at each turn. This means that every turn 
only 3 players will be able to help that territory. When the danger is over, the targeted territory will give 
a �Thank You Bonus� to the player who helped it the most. 


===== 3. ADVANCED CHOICES [Optional] =========
-------------------------
3.1 Making your strategy 
------------------------- 
Every player has two kinds of spendable scores: Resource Points and Global Partnership Points. These 
are indicated on the Player�s HUD, below the objective bar. During a match, every player action deals 
with one or both of the player�s spendables. For instance, to �fetch� a Goal Piece from the top disc, a 
player spends some of his Resources, but when he uses it in a territory, he gains Resources and Global 
Partnership Points.  

The quantity of Resources and Partnership Points earned from helping a territory depend on how much 
that territory was in need of help. For instance, helping Brazil with an Education Goal Piece gives you 
more Resources and Partnership Points in return than using this same peace on a more developed 
country such as Canada.  

So, try your best to use your technology resources to help the territories that need the most. You will be 
rewarded for that. Note that, you can only use Goal Pieces in a territory (other than your objective 
territory) if you have previously established a partnership with it. Partnerships will be explained in detail 
in the next section. 

---------------------
3.5 Natural Disasters
---------------------
Establishing global partnerships is crucial in the player�s strategy for it will allow the player to reach his 
goal faster than the others. 

To establish a partnership, a player needs to select the destination territory with RT or LT. Given that the 
player can do that, a flag with his color will be seen on that territory and he will be able to address Goal 
Pieces to this partner territory. Whether or not the player can make a partnership will be determined by 
his Global Partnership Points as well as the number of Flags he still has available. 
As soon as a player establishes a partnership, he will get a multiplier bonus every time he uses the 
objective goal piece on his objective territory. As he helps the new partner territory this multiplier 
increases, thus making his Objective Bar fill faster, bringing him closer to winning the match. 






