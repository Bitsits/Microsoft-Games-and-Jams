..........:::::Mother Gaia Studio:::::..........


- To learn how to play City Rain go to
  'City Rain' , look 'How to Play' and make
  the CAMPAIGN->TUTORIAL.



~Enjoy