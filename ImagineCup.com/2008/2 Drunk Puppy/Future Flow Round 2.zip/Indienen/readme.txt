Drunk Puppy Is proud to present :

Future Flow (Round 2 Edition)

This version features a fully playable demo level, complete with a how to play, credits, save and load functionality and much more.

Features:

- A original game made on a self-made 3D XNA engine
- Support for multiple graphical themes, but due to time constraints only one theme is fully textured.
- A modern UI that is also very appealing for the eye.
- A chance to meet the designers in the credits screen


Although this version is pretty complete in itself, there are always a few things that can be improved or added.
Things we're going to add in the future :

- Tell Me more screens : information screens offering the player educational value and information about technologies and real life environment problems.
(this is already explained in the help and with 2 to 3 hours of programming more, it would have gotton in the game)
- Particles to add more life to the city
- Level editor to create levels to challenge your friends
- Campaign mode, a series of levels with conditions you have to complete to continue in the game
- Free build mode, offers the player with the freedom to create the city of his/her dreams

We hope you enjoy this game, it has been a great experience making it.
